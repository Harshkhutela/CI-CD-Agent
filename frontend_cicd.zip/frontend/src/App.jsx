import Dashboard from "./pages/Dashboard";
import "./App.css";

function App() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default App;